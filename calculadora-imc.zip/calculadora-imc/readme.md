=== BMI BMR Calculator ===  
Contributors: Fernando Campos de Oliveira  
Tags: IMC TMB, Índice de Massa Corporal, Taxa Metabólica Basal, Calculadora  
Requires at least: 3.7  
Tested up to: 5  
Stable tag: 1.3  
License: MIT  


Calculadora de índice de massa corporal e da taxa metabólica basal.

== Descrição ==

Calculadora de índice de massa corporal e taxa metabólica basal, . O usuário pode simplesmente obter seu IMC e BMR e calcula a porcentagem de gordura corporal com base no IMC, idade e sexo do usuário.

== Instalação ==

1. Faça Upload de `calculadora-imc` para o diretório `/wp-content/plugins/`
1. Ative o plugin através do menu 'Plugins' no WordPress
1. Coloque o shortcode `[bmibmr]` em sua postagem/página

== Perguntas frequentes ==

= Onde estão as configurações? =

Nesta versão, não há página de opções para a calculadora IMC TMB.

= Existem traduções? =

Ainda não.

= Existe painel para o treinador? =

Ainda não

# === doar-paypal-brasil ===
#### Contributors: Fernando Campos (odesenvolvedor)  
#### Donate account PayPal: fernando@odesenvolvedor.net
