<?php
//In case of saving or reading on the first step, code goes here
//--------------------------------------------------------------
echo json_encode($_POST); 